var childheight = 47;
function displayIfChildIsAbleToRideTheRollerCoaster() {
    if (childheight > 52) {
console.log("Get on that ride, kiddo!")
    }
    else {
        console.log("sorry kiddo. Maybe next year")
    }
    }